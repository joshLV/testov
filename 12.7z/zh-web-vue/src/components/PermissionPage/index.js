import PermissionPage from './Permission'

export default PermissionPage
