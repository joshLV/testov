import { axios } from '@/utils/request'

export function productList (parameter) {
  return axios({
    url: '/fbs/product',
    method: 'get',
    params: parameter
  })
}

export function productInfo (id) {
  return axios({
    url: '/fbs/product/' + id,
    method: 'get'
  })
}

export function productSave (parameter) {
  return axios({
    url: '/fbs/product',
    method: 'post',
    data: parameter
  })
}

export function productEdit (id, parameter) {
  return axios({
    url: '/fbs/product/' + id,
    method: 'put',
    data: parameter
  })
}

export function productDelete (id) {
  return axios({
    url: '/fbs/product/' + id,
    method: 'delete'
  })
}

export function productBatchDelete (parameter) {
  return axios({
    url: '/fbs/product',
    method: 'delete',
    data: parameter
  })
}
