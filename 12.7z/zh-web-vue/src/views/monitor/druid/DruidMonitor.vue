<template>
  <iframe src="/druid/index.html" width="100%" height="600px" frameborder="0"></iframe>
</template>
