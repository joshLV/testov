<template>
  <div style="background-color: #ececec; padding: 20px;">
    <a-row :gutter="16">
      <a-col :span="12">
        <a-card title="产品名称： 团体e生保">
          <div style="display:inline" slot="extra">
            <a-tag color="green">契</a-tag>
          </div>
          <a slot="extra" @click="toggleAdvanced" style="margin-left: 8px">
            <a-icon :type="advanced ? 'up' : 'down'"/>
          </a>
          <template v-if="advanced">
            <a-form layout="vertical">
              <a-form-item v-bind="formItemLayout" label="允许在线承保" class="cardFormText">
                <a-switch v-decorator="['switch', { valuePropName1: 'checked' }]"/>
              </a-form-item>
              <a-form-item v-bind="formItemLayout" label="套餐号" class="cardFormText">
                <span class="ant-form-text">1213344113</span>
              </a-form-item>
              <a-form-item v-bind="formItemLayout" label="套餐名称" class="cardFormText">
                <span class="ant-form-text">霸王餐</span>
              </a-form-item>
              <a-form-item>
                计划详情与费类展示
                <a href="#">点击查询</a>
              </a-form-item>

              <a-form-item v-bind="formItemLayout" label="允许智能承保" class="cardFormText">
                <a-switch v-decorator="['switch', { valuePropName2: 'checked' }]"/>
              </a-form-item>
              <a-form-item v-bind="formItemLayout" label="指定机构可见" class="cardFormText">
                <a-switch
                  v-decorator="['switch', { valuePropName3: 'checked' }]"
                  :defaultChecked="checkOrg"
                  @change="e => handleOrgswitch(e)"
                />
              </a-form-item>
              <a-form-item v-show="checkOrg">
                <a href="#">查看配置</a>
              </a-form-item>
              <a-form-item v-bind="formItemLayout" label="指定业务员可见" class="cardFormText">
                <a-switch
                  v-decorator="['switch', { valuePropName4: 'checked' }]"
                  :defaultChecked="checkSman"
                  @change="e => handleSmanswitch(e)"
                />
              </a-form-item>
              <a-form-item v-show="checkSman">
                <a href="#">查看配置</a>
              </a-form-item>
              <a-form-item v-bind="formItemLayout" label="产品开售时间">
                <a-date-picker v-decorator="['date-picker', config]"/>
              </a-form-item>
              <a-form-item v-bind="formItemLayout" label="产品停售时间">
                <a-date-picker v-decorator="['date-picker', config]"/>
              </a-form-item>

              <a-form-item v-bind="formItemLayout" label="中介手续费" class="cardFormText">
                <span class="ant-form-text">15%</span>
              </a-form-item>

              <a-form-item>
                <a-button type="primary" @click="handleSubmit" :loading="confirmLoading" block>保存</a-button>
              </a-form-item>
            </a-form>
          </template>
        </a-card>
      </a-col>

      <a-col :span="12">
        <a-card>
          <a-card-meta title="产品名称 团体e生保">
            <a-avatar
              slot="avatar"
              src="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png"
            />
          </a-card-meta>

          <p>card content</p>
          <p>card content</p>
          <p>card content</p>
          <p>card content</p>
          <p>card content</p>
        </a-card>
      </a-col>
    </a-row>
  </div>
</template>

<script>
import STable from '@/components/Table/'
import checkPermission from '@/utils/permissions'
import { productList, productDelete, productBatchDelete } from '@/api/fbs/product'
import ProductModal from './ProductModal'

export default {
  name: 'ProductList',
  components: {
    ProductModal,
    STable
  },
  data() {
    return {
      formItemLayout: {
        labelCol: {
          xs: { span: 24 },
          sm: { span: 8 }
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 16 }
        }
      }, config: {
        rules: [{ type: 'object', required: true, message: '请选择时间!' }],
      },
      description: '',
      // 高级搜索 展开/关闭
      advanced: true,
      checkOrg: false,
      checkSman: false,
      // 查询参数
      queryParam: {
        content: ''
      },
      confirmLoading: false,
      // 表头
      columns: [
        {
          title: '产品Id',
          dataIndex: 'id'
        },
        {
          title: '产品名称',
          dataIndex: 'name'
        },
        {
          title: '产品编码',
          dataIndex: 'sn'
        },
        {
          title: '产品版本',
          dataIndex: 'version'
        },
        {
          title: '检测号码',
          dataIndex: 'checksum'
        },
        {
          title: '关联机构IDS',
          dataIndex: 'linkedCustomerIds'
        },
        {
          title: '关联用户',
          dataIndex: 'customerId'
        },
        {
          title: '创建人',
          dataIndex: 'createdBy'
        },
        {
          title: '创建时间',
          dataIndex: 'createdDate'
        },
        {
          title: '修改人',
          dataIndex: 'lastModifiedBy'
        },
        {
          title: '修改时间',
          dataIndex: 'lastModifiedDate'
        },

        {
          title: '操作',
          width: '150px',
          dataIndex: 'action',
          scopedSlots: { customRender: 'action' }
        }
      ],
      // 加载数据方法 必须为 Promise 对象
      loadData: parameter => {
        return productList(Object.assign(parameter, this.queryParam))
          .then(res => {
            return res
          })
          .catch(e => {})
      },

      selectedRowKeys: [],
      selectedRows: [],
      // custom table alert & rowSelection
      options: {
        alert: { show: true, clear: true },
        rowSelection: {
          selectedRowKeys: this.selectedRowKeys,
          onChange: this.onSelectChange
        }
      }
    }
  },
  methods: {
    checkPermission,
    handleSubmit() {
      // this.confirmLoading = true;
      this.$message.success('保存成功')
    },
    handleFilter() {
      this.$refs.table.refresh(true)
    },
    clearFilter() {
      this.queryParam.content = ''
    },
    handleTableRefresh(boolean) {
      this.$refs.table.refresh(boolean)
    },
    handleDelete(record) {
      const that = this
      this.$confirm({
        type: 'error',
        title: '提示',
        content: '真的要删除吗 ?',
        okType: 'danger',
        okText: '删除',
        onOk() {
          return productDelete(record.id)
            .then(() => {
              that.$message.success('删除成功')
            })
            .catch(err => {
              that.$message.error('删除失败')
            })
            .finally(() => {
              that.$refs.table.refresh(false)
              // 批量删除完毕后清空复选框
              that.$refs.table.clearSelected()
            })
        },
        onCancel() {}
      })
    },
    handleswitch(e) {
      console.log(e)
    },
    handleOrgswitch(e) {
      this.checkOrg = e
    },
    handleSmanswitch(e) {
      this.checkSman = e
    },
    handleBatchDelete(selectedRowKeys) {
      const that = this
      this.$confirm({
        type: 'error',
        title: '提示',
        content: '真的要删除选中内容吗 ?',
        okType: 'danger',
        okText: '删除',
        onOk() {
          return productBatchDelete(selectedRowKeys)
            .then(() => {
              that.$message.success('删除成功')
            })
            .catch(err => {
              that.$message.error('删除失败')
            })
            .finally(() => {
              that.$refs.table.refresh(false)
              // 批量删除完毕后清空复选框
              that.$refs.table.clearSelected()
            })
        },
        onCancel() {}
      })
    },
    onSelectChange(selectedRowKeys, selectedRows) {
      this.selectedRowKeys = selectedRowKeys
      this.selectedRows = selectedRows
    },
    toggleAdvanced() {
      this.advanced = !this.advanced
    }
  }
}
</script>
<style lang="less" scoped>
.cardFormText {
  margin-bottom: 0px;

  .ant-form-item-label {
    height: 22px;
    line-height: 22px;
  }
  .ant-form-item-control-wrapper {
    height: 22px;
    line-height: 22px;
  }
}
</style>
