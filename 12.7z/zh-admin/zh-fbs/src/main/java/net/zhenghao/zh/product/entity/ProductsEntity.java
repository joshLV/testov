package net.zhenghao.zh.product.entity;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 产品
 *
 * ProductsEntity.java
 */
public class ProductsEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/**
	 * 产品Id
	 */
	private Long id;
	
	/**
	 * 产品名称
	 */
	private String name;
	
	/**
	 * 产品编码
	 */
	private String sn;
	
	/**
	 * 产品版本
	 */
	private String version;
	
	/**
	 * 检测号码
	 */
	private String checksum;
	
	/**
	 * 关联机构IDS
	 */
	private String linkedCustomerIds;
	
	/**
	 * 关联用户
	 */
	private Long customerId;
	
	/**
	 * 创建人
	 */
	private String createdBy;
	
	/**
	 * 创建时间
	 */
	private Timestamp createdDate;
	
	/**
	 * 修改人
	 */
	private String lastModifiedBy;
	
	/**
	 * 修改时间
	 */
	private Timestamp lastModifiedDate;
	
	
	public ProductsEntity() {
		super();
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getId() {
		return id;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setSn(String sn) {
		this.sn = sn;
	}
	
	public String getSn() {
		return sn;
	}
	
	public void setVersion(String version) {
		this.version = version;
	}
	
	public String getVersion() {
		return version;
	}
	
	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}
	
	public String getChecksum() {
		return checksum;
	}
	
	public void setLinkedCustomerIds(String linkedCustomerIds) {
		this.linkedCustomerIds = linkedCustomerIds;
	}
	
	public String getLinkedCustomerIds() {
		return linkedCustomerIds;
	}
	
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	
	public Long getCustomerId() {
		return customerId;
	}
	
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	
	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}
	
}