package net.zhenghao.zh.product.dao;

import net.zhenghao.zh.common.dao.BaseMapper;
import net.zhenghao.zh.product.entity.ProductsEntity;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.stereotype.Component;

/**
 * 产品
 *
 * ProductsMapper.java
 */
@MapperScan
@Component
public interface ProductsMapper extends BaseMapper<ProductsEntity> {
	
}