package net.zhenghao.zh.product.service;

import net.zhenghao.zh.common.entity.Page;
import net.zhenghao.zh.common.entity.Result;
import net.zhenghao.zh.product.entity.ProductsEntity;

import java.util.Map;

/**
 * 产品日志
 *
 * ProductsService.java
 */
public interface ProductsService {

	Page<ProductsEntity> listProducts(Map<String, Object> params);

    Result<ProductsEntity> getProductsById(Long id);

    Result<Void>  saveProducts(ProductsEntity products);

    Result<Void>  updateProducts(ProductsEntity products);

    Result<Void>  removeProducts(Long id);

    Result<Void>  batchRemove(Long[] ids);
	
}