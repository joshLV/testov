package net.zhenghao.zh.product.controller;

import net.zhenghao.zh.common.annotation.SysLog;
import net.zhenghao.zh.common.controller.AbstractController;
import net.zhenghao.zh.common.entity.Page;
import net.zhenghao.zh.common.entity.Result;
import net.zhenghao.zh.product.entity.ProductsEntity;
import net.zhenghao.zh.product.service.ProductsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 产品
 *
 * ProductsController.java
 */
@RestController
@RequestMapping("${zh-admin.api.prefix}/fbs/product")
public class ProductsController extends AbstractController {

	@Autowired
	private ProductsService productsService;
	
	/**
	 * 列表
	 * @param params
	 * @return
	 */
	@GetMapping("")
	public Page<ProductsEntity> list(@RequestParam Map<String, Object> params) {
		return productsService.listProducts(params);
	}

    /**
     * 根据id查询详情
     * @param id
     * @return
     */
    @GetMapping("/{id}")
    public Result<ProductsEntity> info(@PathVariable("id") Long id) {
        return productsService.getProductsById(id);
    }

    /**
	 * 新增
	 * @param products
	 * @return
	 */
    @SysLog("新增产品")
    @PostMapping("")
    public Result save(@RequestBody ProductsEntity products) {
        //products.setCreatorId(getUserId());
    	 products.setCreatedBy(getUserId().toString());
        return productsService.saveProducts(products);
    }

    /**
	 * 修改
	 * @param id
	 * @param products
	 * @return
	 */
    @SysLog("修改产品")
    @PutMapping("/{id}")
    public Result<Void>  update(@PathVariable("id") Long id, @RequestBody ProductsEntity products) {
        products.setId(id);
      //  products.setModifierId(getUserId());
        
        products.setCreatedBy(getUserId().toString());
        return productsService.updateProducts(products);
    }

    /**
	 * 删除
	 * @param id
	 * @return
	 */
    @SysLog("删除产品")
    @DeleteMapping("/{id}")
    public Result<Void> remove(@PathVariable("id") Long id) {
        return productsService.removeProducts(id);
    }

    /**
	 * 批量删除
	 * @param ids
	 * @return
	 */
    @SysLog("批量删除产品")
    @DeleteMapping("")
    public Result<Void>  batchRemove(@RequestBody Long[] ids) {
        return productsService.batchRemove(ids);
    }
	
}