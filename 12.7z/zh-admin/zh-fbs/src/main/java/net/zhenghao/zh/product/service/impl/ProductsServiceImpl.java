package net.zhenghao.zh.product.service.impl;

import com.github.pagehelper.PageHelper;
import net.zhenghao.zh.product.dao.ProductsMapper;
import net.zhenghao.zh.common.entity.Page;
import net.zhenghao.zh.common.entity.Query;
import net.zhenghao.zh.common.entity.Result;
import net.zhenghao.zh.common.utils.CommonUtils;
import net.zhenghao.zh.product.entity.ProductsEntity;
import net.zhenghao.zh.product.service.ProductsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

/**
 * 产品日志
 *
 * ProductsServiceImpl.java
 */
@Service("productsService")
@Transactional
public class ProductsServiceImpl implements ProductsService {

	@Autowired
	private ProductsMapper productsMapper;
	
	@Override
	public Page<ProductsEntity> listProducts(Map<String, Object> params) {
		Query query = new Query(params);
		Page<ProductsEntity> page = new Page<>(query);
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        page.setData(productsMapper.listForPage(query));
		return page;
	}

    @Override
    public Result<ProductsEntity> getProductsById(Long id) {
		ProductsEntity products = productsMapper.getObjectById(id);
        return CommonUtils.msg(products);
    }

	@Override
	public Result<Void>  saveProducts(ProductsEntity products) {
		int count = productsMapper.save(products);
		return CommonUtils.msg(count);
	}

	@Override
	public Result<Void>  updateProducts(ProductsEntity products) {
		int count = productsMapper.update(products);
		return CommonUtils.msg(count);
	}

    @Override
    public Result<Void>  removeProducts(Long id) {
        int count = productsMapper.remove(id);
        return CommonUtils.msg(count);
    }

	@Override
	public Result<Void>  batchRemove(Long[] ids) {
		int count = productsMapper.batchRemove(ids);
		return CommonUtils.msg(ids, count);
	}
	
}