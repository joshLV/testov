INSERT INTO `sys_post` VALUES (3, '董事长', 'ceo', 0, 1, '2019-4-29 23:19:42', NULL, NULL);
INSERT INTO `sys_post` VALUES (4, '项目经理', 'pm', 1, 1, '2019-4-29 23:19:45', NULL, NULL);
INSERT INTO `sys_post` VALUES (5, '人力资源', 'hr', 2, 1, '2019-4-29 23:19:48', NULL, NULL);
INSERT INTO `sys_post` VALUES (6, '普通员工', 'user', 3, 1, '2019-4-29 23:19:51', NULL, NULL);
INSERT INTO `sys_post` VALUES (7, '会计', 'accountant', 4, 1, '2019-4-29 23:19:53', NULL, NULL);
INSERT INTO `sys_post` VALUES (8, '前端工程师', 'fe', 5, 1, '2019-4-29 23:19:55', NULL, NULL);
INSERT INTO `sys_post` VALUES (9, '后端工程师', 'rd', 6, 1, '2019-4-29 23:19:57', NULL, NULL);
