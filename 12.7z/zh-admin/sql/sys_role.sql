INSERT INTO `sys_role` VALUES (1, '超级管理员', 'admin', '【系统内置】', 1, '2017-12-20 14:34:21', NULL, NULL);
INSERT INTO `sys_role` VALUES (29, '只读角色', 'read-only', NULL, 1, '2019-3-30 15:29:25', 1, '2019-4-5 00:36:35');
INSERT INTO `sys_role` VALUES (30, '测试', 'test', '测试', 1, '2019-6-1 21:50:17', NULL, NULL);
