INSERT INTO `products` VALUES (1, '产品一', '121344', '1', '20000', '1,3,4', 1, '1', '2019-6-2 16:53:52', NULL, NULL);
