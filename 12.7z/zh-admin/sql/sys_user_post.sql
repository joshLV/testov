INSERT INTO `sys_user_post` VALUES (9, 63, 4);
INSERT INTO `sys_user_post` VALUES (10, 63, 9);
INSERT INTO `sys_user_post` VALUES (19, 1, 9);
INSERT INTO `sys_user_post` VALUES (20, 1, 8);
INSERT INTO `sys_user_post` VALUES (21, 64, 8);
INSERT INTO `sys_user_post` VALUES (22, 64, 5);
INSERT INTO `sys_user_post` VALUES (23, 64, 4);
