INSERT INTO `sys_user_role` VALUES (27, 63, 29);
INSERT INTO `sys_user_role` VALUES (32, 1, 1);
INSERT INTO `sys_user_role` VALUES (33, 64, 30);
