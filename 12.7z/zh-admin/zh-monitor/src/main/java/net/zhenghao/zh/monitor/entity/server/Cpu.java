package net.zhenghao.zh.monitor.entity.server;

/**
 * 🙃
 * 🙃 cpu信息
 * 🙃
 * Cpu.java
 */

public class Cpu {

    /**
     * 核心数
     */
    private Integer cpuNum;

    /**
     * CPU用户使用率
     */
    private Integer usedPercent;

    public Integer getCpuNum() {
        return cpuNum;
    }

    public void setCpuNum(Integer cpuNum) {
        this.cpuNum = cpuNum;
    }

    public Integer getUsedPercent() {
        return usedPercent;
    }

    public void setUsedPercent(Integer usedPercent) {
        this.usedPercent = usedPercent;
    }
}
