package net.zhenghao.zh.auth.service;

import java.util.List;
import java.util.Map;

import net.zhenghao.zh.common.entity.Page;
import net.zhenghao.zh.common.entity.Result;
import net.zhenghao.zh.common.entity.SysLogEntity;
import net.zhenghao.zh.common.vo.ChartVO;
import net.zhenghao.zh.common.vo.VisitCountVO;

/**
 * 系统日志service层
 *
 */
public interface SysLogService {

	Page<SysLogEntity> listLog(Map<String, Object> params);
	
	Result<Void> batchRemove(Long[] ids);

	Result<Void> batchRemoveAll(Integer type);

	Result<VisitCountVO> visitCount();

	Result<List<ChartVO>> lastWeekVisitCount();
	
	
	Result<Void> saveSysLog(SysLogEntity syslog);
	
	
}
