package net.zhenghao.zh.auth.disruptor.translator;

import com.lmax.disruptor.EventTranslatorOneArg;

import net.zhenghao.zh.auth.disruptor.event.SysLogEvent;
import net.zhenghao.zh.common.entity.SysLogEntity;

public class SysLogEventTranslator   implements EventTranslatorOneArg<SysLogEvent, SysLogEntity> {

	@Override
	public void translateTo(SysLogEvent event, long sequence, SysLogEntity log) {
		
		event.setLog(log);
	}

	

	

}
