package net.zhenghao.zh.auth.disruptor.publisher;

import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.lmax.disruptor.BlockingWaitStrategy;
import com.lmax.disruptor.IgnoreExceptionHandler;
import com.lmax.disruptor.RingBuffer;
import com.lmax.disruptor.dsl.Disruptor;
import com.lmax.disruptor.dsl.ProducerType;

import net.zhenghao.zh.auth.disruptor.event.SysLogEvent;
import net.zhenghao.zh.auth.disruptor.factory.SysLogEventFactory;
import net.zhenghao.zh.auth.disruptor.handler.SysLogHandler;
import net.zhenghao.zh.auth.disruptor.translator.SysLogEventTranslator;
import net.zhenghao.zh.auth.service.SysLogService;
import net.zhenghao.zh.common.concurrent.CommonThreadFactory;
import net.zhenghao.zh.common.entity.SysLogEntity;

/**
 * 日志事件生产者
 */
@Component // 添加器
public class LogEventPublisher implements InitializingBean, DisposableBean {

	private Disruptor<SysLogEvent> disruptor;

	@Value("${disruptor.bufferSize:1024}")
	private int bufferSize;

	@Value("${disruptor.threadSize:10}")
	private int threadSize;

	private final SysLogService sysLogService;

	@Autowired(required = false)
	public LogEventPublisher(SysLogService sysLogService) {
		this.sysLogService = sysLogService;
	}

	private void start() {
		SysLogEventFactory requestEventFactory = new SysLogEventFactory();
		// 这里默认的生产这是多线程
		// disruptor = new Disruptor<SysLogEvent>(requestEventFactory, threadSize,
		// Executors.defaultThreadFactory());
		disruptor = new Disruptor<>(requestEventFactory, bufferSize, r -> {
			AtomicInteger index = new AtomicInteger(1);
			return new Thread(null, r, "log-thread-" + index.getAndIncrement());
		}, ProducerType.MULTI, new BlockingWaitStrategy());

		final Executor executor = new ThreadPoolExecutor(threadSize, threadSize, 0, TimeUnit.MILLISECONDS,
				new LinkedBlockingQueue<>(), CommonThreadFactory.create("log-disruptor", false),
				new ThreadPoolExecutor.AbortPolicy());

		SysLogHandler[] consumers = new SysLogHandler[threadSize];
		for (int i = 0; i < threadSize; i++) {
			consumers[i] = new SysLogHandler(executor, sysLogService);
		}
		disruptor.handleEventsWithWorkerPool(consumers);
		disruptor.setDefaultExceptionHandler(new IgnoreExceptionHandler());
		disruptor.start();

	}
	
    /**
     * publish disruptor event.
     *
     * @param sysLog data.
     */
    public void publishEvent(final SysLogEntity sysLog) {
        final RingBuffer<SysLogEvent> ringBuffer = disruptor.getRingBuffer();
        ringBuffer.publishEvent(new SysLogEventTranslator(), sysLog);
    }

	@Override
	public void destroy() throws Exception {
		disruptor.shutdown();

	}

	@Override
	public void afterPropertiesSet() throws Exception {
		start();

	}
}